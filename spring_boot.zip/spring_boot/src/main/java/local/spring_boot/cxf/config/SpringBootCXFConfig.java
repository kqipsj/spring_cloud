package local.spring_boot.cxf.config;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import local.spring_boot.cxf.service.SpringBootCXFService;

@Configuration
public class SpringBootCXFConfig {
	
	@Autowired
    private Bus bus;
	
	@Autowired
	private SpringBootCXFService springBootCXFService;
	
	@Bean
	public Endpoint endpoint() {
		Endpoint endpoint = new EndpointImpl(bus,springBootCXFService);
		endpoint.publish("/service");
		return endpoint;
	}

}
