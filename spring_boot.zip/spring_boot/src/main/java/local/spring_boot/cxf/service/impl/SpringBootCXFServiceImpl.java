package local.spring_boot.cxf.service.impl;

import javax.jws.WebService;

import local.spring_boot.cxf.entity.User;
import org.springframework.stereotype.Component;

import local.spring_boot.cxf.service.SpringBootCXFService;

@WebService(targetNamespace="http://service.cxf.com/")
@Component
public class SpringBootCXFServiceImpl implements SpringBootCXFService{

	public String sendMessage(String message) {
		return message;
	}

	public String getIP() {
		return "192.168.1.1";
	}

	public User getName(String username) {
		User user = new User();
		user.setId(1);
		user.setName(username);
		user.setTelephone("18539578302");
		return user;
	}

}
