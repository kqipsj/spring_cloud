package local.spring_boot.cxf.service;

import local.spring_boot.cxf.entity.User;

import javax.jws.WebService;

@WebService
public interface SpringBootCXFService {
	
	String sendMessage(String message);

	User getName(String username);

	String getIP();

}
