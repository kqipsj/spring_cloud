package local.spring_boot.local.test.classload;

public class ParentClass {
    static {
        System.out.println("Parent Class static code!");
    }

    {
        System.out.println("Parent Class not static code!");
    }

    public ParentClass(){
        System.out.println("Parent Class Constracter!");
    }
}
