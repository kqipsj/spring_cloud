package local.spring_boot.local.test.classload;

public class ChildClass extends ParentClass{
    static {
        System.out.println("Child Class static demo!");
    }

    {
        System.out.println("Child Class not static demo!");
    }

    public ChildClass(){
        super();
        System.out.println("Child Class Constracter!");
    }
}
