package local.spring_boot.local.test.classload;

public class Test {
    public static void main(String[] args) {
        ChildClass child = new ChildClass();
        System.out.println("---------------------------");
        ChildClass childClass = new ChildClass();
    }
}
