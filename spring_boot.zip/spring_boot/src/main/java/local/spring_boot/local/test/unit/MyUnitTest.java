package local.spring_boot.local.test.unit;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

public class MyUnitTest {

    public static void main(String[] args) {
        testBigDecimal();
        jsonTest();
        testCalender();
    }

    private static void testCalender(){
        Date purchaseDate = new Date();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(purchaseDate);
        calendar.add(Calendar.DAY_OF_MONTH,-8);

        int year = calendar.get(Calendar.YEAR) - 1900;
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        Date startDate = new Date(year,month,6);
        Date endDate = new Date(year,month,11);

        System.out.println(purchaseDate.before(endDate) && purchaseDate.after(startDate));

        System.out.println(day >= 6 && day <= 10);
    }

    public static void testBigDecimal(){
        System.out.println(calculateLevel(new BigDecimal(99198)));
    }

    private static int calculateLevel(BigDecimal amount){
        int level = 0;

        if(amount.compareTo(new BigDecimal(1000)) < 0){
            level = 3;
        }else if (amount.compareTo(new BigDecimal(10000)) < 0){
            level = 4;
        }else {
            level = 5;
        }
        return level;
    }

    public static void jsonTest(){
        String jsonStr = "{\n" +
                "    \"productList\":[\n" +
                "        {\n" +
                "            \"code\":\"Group_WT03\",\n" +
                "            \"title\":\"3月见证产品组\",\n" +
                "            \"tags\":\"银行信息见证 | 等额本息回款\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"YL0000\",\n" +
                "            \"title\":\"随存随取\",\n" +
                "            \"tags\":\"亿联银行 | 当日起息 | 支取无限额\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"FM0000\",\n" +
                "            \"title\":\"随存随取\",\n" +
                "            \"tags\":\"富民银行 | <span style=‘color:#ff7700’>本金保障</span> | 当日起息\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"XW005Y\",\n" +
                "            \"title\":\"5年 定期\",\n" +
                "            \"tags\":\"新网银行 | 当日起息 | 无风险\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"XW0299\",\n" +
                "            \"title\":\"299天 定期\",\n" +
                "            \"tags\":\"新网银行 | 当日起息 | 提前可取\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"XW005Y3M\",\n" +
                "            \"title\":\"90天 按期付息\",\n" +
                "            \"tags\":\"新网银行 | 每90天付息 | 提前可取\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"Group_WT06\",\n" +
                "            \"title\":\"6月见证产品组\",\n" +
                "            \"tags\":\"银行信息见证 | 等额本息回款\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"XW0199\",\n" +
                "            \"title\":\"199天 定期\",\n" +
                "            \"tags\":\"新网银行 | 当日起息 | 提前可取\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"code\":\"Group_WA012\",\n" +
                "            \"title\":\"12月见证产品组\",\n" +
                "            \"tags\":\"银行信息见证 | 等额本息回款\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        JsonObject jsonObject = new JsonParser().parse(jsonStr).getAsJsonObject();
        JsonArray products = jsonObject.get("productList").getAsJsonArray();
        for (JsonElement element : products) {
            JsonObject product = element.getAsJsonObject();
            System.out.println(product.get("code").getAsString());
        }

    }
}
