package local.spring_boot.webmvc.controller;

import local.spring_boot.webmvc.entity.User;
import local.spring_boot.webmvc.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
@ResponseBody
@RequestMapping("/action")
public class TestController {

    @Autowired
    private TestService testService;

    @RequestMapping("/test")
    public Object testController(){
        return "test message";
    }

    @RequestMapping("/loadAllUser")
    public List<User> loadAllUser(){
        return testService.loadAllUser();
    }

    @RequestMapping("/createUser")
    public User createUser(User user){
        return testService.createUser(user);
    }

    @RequestMapping("/loadUserById")
    public User loadUserById(Long id){
        return testService.loadUserById(id);
    }

}
