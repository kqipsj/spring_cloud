package local.spring_boot.webmvc.service;

import local.spring_boot.webmvc.entity.User;

import java.util.List;

public interface TestService {

    List<User> loadAllUser();

    User createUser(User user);

    User loadUserById(Long id);
}
