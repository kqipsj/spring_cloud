package local.spring_boot.webmvc.service.impl;

import local.spring_boot.webmvc.dao.TestRepository;
import local.spring_boot.webmvc.entity.User;
import local.spring_boot.webmvc.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestServiceImpl implements TestService {
    @Autowired
    private TestRepository repository;
    @Override
    public List<User> loadAllUser() {
        return (List<User>) repository.findAll();
    }

    @Override
    public User createUser(User user) {
        return repository.save(user);
    }

    @Override
    public User loadUserById(Long id) {
        return repository.findById(id).get();
    }
}
